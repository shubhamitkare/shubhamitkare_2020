package myPack;
import java.util.Scanner;

class coffeeshop
{
    private int top;
    private coffee[] drink;
    private double vat;
    private double servicetax;
    private double cess;
  
    public coffeeshop() 
    {
        this.top = 4;
        this.vat = 12.5D;
        this.servicetax = 5.0D;
        this.cess = 3.0D;
        this.drink = new coffee[10];
        this.drink[0] = new coffee("Cafe Americano", 75, 1);
        this.drink[1] = new coffee("Cafe Latte", 78, 2);
        this.drink[2] = new coffee("Cafe Mocha", 85, 3);
        this.drink[3] = new coffee("Cappuccino", 110, 4);
        this.drink[4] = new coffee("Espresso", 90, 5);
    }
  
    public void setVat(double vat) throws Exception
    {
        if (vat >= 0.0D)
        {
            this.vat = vat;
        }
        else
        {
            throw new Exception("Invalid vat");
        } 
    }
  
    public double getVat()
    {
        return this.vat;
    }
  
    public void setServiceTax(double servicetax) throws Exception 
    {
        if (servicetax >= 0.0D)
        {
            this.servicetax = servicetax;
        } 
        else
        {
            throw new Exception("Invalid servicetax");
        }   
    }
  
    public double getServiceTax()
    {
        return this.servicetax;
    }
  
    public void setCess(double cess) throws Exception
    {
        if (cess >= 0.0D)
        {
            this.cess = cess;
        }
        else
        {
            throw new Exception("Invalid Service Charges");
        } 
    }
  
    public double getCess() 
    {
        return this.cess;
    }
  
    public double getAmount(double amount)
    {
        return (getVat() + getServiceTax() + getCess() + 100.0D) * amount / 100.0D;
    }
  
    public boolean isEmpty()
    {
        if (this.top == -1)
        return true; 
        return false;
    }
  
    public void add(coffee item) 
    {
        if (this.top >= this.drink.length - 1)
        {
            coffee[] temp = new coffee[this.drink.length * 2];
          
            for (int i = 0; i < this.drink.length; i++)
            
                temp[i] = this.drink[i]; 
    
               this.drink = temp;
        } 
          this.top++;
          this.drink[this.top] = item;
    }
  
    public void delete(int code) throws Exception
    {
        if (isEmpty())
            throw new Exception("Menu is Already Empty. No Drinks to Delete.");
        if (!isIcode(code))
            throw new Exception("No Coffee Found to Delete."); 
            
        int i;
        
        for (i = 0; i <= this.top && this.drink[i].getIcode() != code; i++)
            
            for (; i < this.top + 1 && i < this.drink.length; i++)
        
                this.drink[i] = this.drink[i + 1]; 
            
                this.top--;
  }
  
  public boolean isIcode(int code)
  {
      for (int i = 0; i <= this.top; )
      {
          int temp = this.drink[i].getIcode();
         
          if (temp != code)
          {
              i++;
              continue;
          } 
	  else
	  {return true;}
      } 
       return false;
  }
  
  public coffee coffeewithIcode(int icode) throws Exception
  {
      if (!isIcode(icode))
      throw new Exception("No Coffee Found."); 
      int i;
      for ( i =0 ; i <= this.top;)
      {
          if (this.drink[i].getIcode() != icode)
              
              i++;
          else
              break;								
      } 
	return this.drink[i];
  }
  
  public void displaymenu()
  {
      System.out.println();
      System.out.println("********************** CAFE COFFEE DAY **********************");
      System.out.println("SNO                    NAME                    PRICE    ICODE");
    
      for (int i = 0; i <= this.top; i++)
      {
          if(i<9)
          System.out.print((i + 1) + "   ");
          else
              System.out.print((i + 1) + "  ");
          System.out.print(this.drink[i].getName());
         
          int j;
          for (j = 0; j < 44 - this.drink[i].getName().length() ; j++)
          System.out.print(" "); 
          
          System.out.print(this.drink[i].getPrice());
         
          for (j = 0; j < 10 - (this.drink[i].getPrice() + " ").length(); j++)
          System.out.print(" "); 
      
          System.out.println(this.drink[i].getIcode());
      } 
  }
  
  public void displaytaxes()
  {
      System.out.println();
      System.out.println("********************** CAFE COFFIEE DAY **********************");
      System.out.println("Vat             : " + getVat() + "%");
      System.out.println("Service Tax     : " + getServiceTax() + "%");
      System.out.println("Service Charges : " + getCess() + "%");
  }
  
  public void bill(boolean isLucky)
  {
      Scanner scn = new Scanner(System.in);
      
      if (isLucky)
          System.out.println("Congratulations you are our lucky customer.\nYou can start placing your order now:"); 
        
          Double amount = Double.valueOf(0.0D), discount = Double.valueOf(0.0D);
     
          while (true)
          {
              coffee drink;
              int quantity, icode;
           try
           {
               System.out.print("Enter Coffee Icode: ");
               icode = scn.nextInt();
               drink = coffeewithIcode(icode);
           }
           catch (Exception e)
           {
               System.out.println(e);
               return;
           } 
           try
           {
               System.out.print("Enter " + coffeewithIcode(icode).getName() + " Quanity: ");
               quantity = scn.nextInt();
            
               if (quantity <= 0)
                   throw new Exception("Invalid Quantity"); 
           } 
           catch (Exception e)
           {
               System.out.println(e);
               return;
           } 
            amount = Double.valueOf(amount.doubleValue() + (drink.getPrice() * quantity));
            System.out.println("Want to add more items to your order? (yes/no)");
            String ans = scn.next();
      
            if (!ans.equals("yes")) 
            {
                System.out.println();
                System.out.println("######################       BILL      ######################");
                System.out.println("Base Price         : Rs" + amount);
        
                if (isLucky)
                {
                    System.out.println("Lucky Draw         : -Rs" + (amount.doubleValue() / 2.0D));
                    discount = Double.valueOf(amount.doubleValue() / 2.0D);
                }
                else if (amount.doubleValue() > 750.0D)
                {
                    System.out.println("Discount           : -Rs100"); 
                    discount = Double.valueOf(100.0D);
                } 
                else if (amount.doubleValue() > 500.0D)
                {
                    System.out.println("Discount           : -Rs50");
                    discount = Double.valueOf(50.0D);
                } 
                amount = Double.valueOf(amount.doubleValue() - discount.doubleValue());
                System.out.println("Discounted Price    : Rs" + amount);
                System.out.println("Vat           " + getVat() + "%: Rs" + (getVat() * amount.doubleValue() / 100.0D));
                System.out.println("Service Tax    " + getServiceTax() + "%: Rs" + (getServiceTax() * amount.doubleValue() / 100.0D));
                System.out.println("Service Charges" + getCess() + "%: Rs" + (getCess() * amount.doubleValue() / 100.0D));
                System.out.println("Total Price        : Rs" + getAmount(amount.doubleValue()));
                System.out.println("######################    THANK YOU    ######################");
                return;
      } 
    } 
  }
}